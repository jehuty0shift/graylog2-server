module StatisticsHelper
end
