module HostsHelper
end
